import React from "react";

function Navbar() {
  return (
    <header>
      <nav>
        <div className="logo">
          <img src="images/Blue Simple Education Logo.png" alt="Logo" />
        </div>
        <div className="links">
          <ul className="nav-links">
            <li>
              <a href="#">Home</a>
            </li>
            <li>
              <a href="#">About</a>
            </li>
            <li>
              <a href="#">Courses</a>
            </li>
          </ul>
          <div className="auth-buttons">
            <a href="#" className="login-btn">
              Login
            </a>
            <a href="#" className="signup-btn">
              Signup
            </a>
          </div>
        </div>
      </nav>
    </header>
  );
}

export default Navbar;
