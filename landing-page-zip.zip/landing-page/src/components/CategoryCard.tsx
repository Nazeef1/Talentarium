import React from "react";

interface Props {
  image: string;
  title: string;
  altText: string;
}

function CategoryCard({ image, title, altText }: Props) {
  return (
    <div className="category-box">
      <img src={image} alt={altText} />
      <p>{title}</p>
    </div>
  );
}

export default CategoryCard;
