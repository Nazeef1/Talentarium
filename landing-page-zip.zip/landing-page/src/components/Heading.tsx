import React from "react";

interface Props {
  title: string;
  highlight: string;
}

function Heading({ title, highlight }: Props) {
  return (
    <div className="heading">
      <h1>{title}</h1>
      <h1 className="talentarium">{highlight}</h1>
    </div>
  );
}

export default Heading;
